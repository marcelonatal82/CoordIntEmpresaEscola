package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.EstagioController;
import model.Estagio;
import repositorio.DBConnection;
import repositorio.EstagioRepositorio;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class VEstagio extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdMod;
	private JTextField txtModalidade;
	private JTable tbEstagio;
	private JTextField txtDataInicio;
	private JTextField txtDataFim;
	private JTextField txtDtPreEnt;
	private JTextField txtDataCad;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VEstagio frame = new VEstagio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VEstagio() {
		setTitle("Cadastro de Estagio");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 485);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Estagio estagio = new Estagio();
				EstagioController cieeController = new EstagioController();
										
				estagio.setId(Integer.valueOf(txtIdMod.getText()));
				estagio.setModalidade_estagio(Integer.valueOf(txtModalidade.getText()));
				estagio.setData_inicio(txtDataInicio.getText());
				estagio.setData_fim(txtDataFim.getText());
				estagio.setData_previsao_entrega(Integer.valueOf(txtDtPreEnt.getText()));
				estagio.setData_cadastro(txtDataCad.getText());
		
												
				boolean resultado = cieeController.salvar(estagio);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(63, 377, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(396, 377, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 339);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(22, 21, 12, 16);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtIdMod = new JTextField();
		txtIdMod.setBounds(21, 43, 95, 26);
		txtIdMod.setColumns(10);
		
		txtModalidade = new JTextField();
		txtModalidade.setBounds(21, 123, 345, 26);
		txtModalidade.setColumns(10);
		
		JLabel lblNumero_matricula = new JLabel("Modalidade de Estagio");
		lblNumero_matricula.setBounds(21, 103, 170, 16);
		lblNumero_matricula.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.setLayout(null);
		panel.add(txtIdMod);
		panel.add(lblId);
		panel.add(lblNumero_matricula);
		panel.add(txtModalidade);
		
		JLabel lblNewLabel = new JLabel("Data de Inicio");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(21, 173, 95, 14);
		panel.add(lblNewLabel);
		
		txtDataInicio = new JTextField();
		txtDataInicio.setBounds(21, 188, 132, 20);
		panel.add(txtDataInicio);
		txtDataInicio.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Data de Fim");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(184, 173, 75, 14);
		panel.add(lblNewLabel_1);
		
		txtDataFim = new JTextField();
		txtDataFim.setBounds(184, 188, 132, 20);
		panel.add(txtDataFim);
		txtDataFim.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Data de previsão entrega");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(358, 173, 138, 14);
		panel.add(lblNewLabel_2);
		
		txtDtPreEnt = new JTextField();
		txtDtPreEnt.setBounds(384, 188, 75, 20);
		panel.add(txtDtPreEnt);
		txtDtPreEnt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Data de Cadastro");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(342, 23, 104, 14);
		panel.add(lblNewLabel_3);
		
		txtDataCad = new JTextField();
		txtDataCad.setBounds(336, 43, 110, 26);
		panel.add(txtDataCad);
		txtDataCad.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from estagio";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbEstagio.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("modalidade_estagio"), rs.getString("data_previsao_entrega"), rs.getString("data_inicio"), rs.getString("data_fim"), rs.getString("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 252);
		panel_1.add(scrollPane);
		
		tbEstagio = new JTable();
		tbEstagio.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbEstagio.getSelectedRow();
				
						
				txtIdMod.setText(tbEstagio.getValueAt(linha, 0).toString());
				txtModalidade.setText(tbEstagio.getValueAt(linha, 1).toString());
				txtDtPreEnt.setText(tbEstagio.getValueAt(linha, 2).toString());
				txtDataInicio.setText(tbEstagio.getValueAt(linha, 3).toString());
				txtDataFim.setText(tbEstagio.getValueAt(linha, 4).toString());
				txtDataCad.setText(tbEstagio.getValueAt(linha, 5).toString());
			
				
			}
		});
		tbEstagio.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbEstagio.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"ID", "MODALIDADE ESTAGIO", "DATA PREVISAO ENTREGA", "DATA FIM", "DATA INICIO", "DATA CADASTRO"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbEstagio.getColumnModel().getColumn(0).setPreferredWidth(56);
		tbEstagio.getColumnModel().getColumn(1).setPreferredWidth(99);
		tbEstagio.getColumnModel().getColumn(2).setPreferredWidth(143);
		tbEstagio.getColumnModel().getColumn(3).setPreferredWidth(184);
		tbEstagio.getColumnModel().getColumn(4).setPreferredWidth(152);
		tbEstagio.getColumnModel().getColumn(5).setPreferredWidth(143);
		
		scrollPane.setViewportView(tbEstagio);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				Estagio estagio = new Estagio();
				EstagioController cieeController = new EstagioController();
										
				estagio.setId(Integer.valueOf(txtIdMod.getText()));
				estagio.setModalidade_estagio(Integer.valueOf(txtModalidade.getText()));
				estagio.setData_inicio(txtDataInicio.getText());
				estagio.setData_fim(txtDataFim.getText());
				estagio.setData_previsao_entrega(Integer.valueOf(txtDtPreEnt.getText()));
				estagio.setData_cadastro(txtDataCad.getText());	
		
								
				boolean resultado = cieeController.alterar(estagio);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(176, 377, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			Estagio estagio = new Estagio();
			EstagioController cieeController = new EstagioController();
									
			estagio.setId(Integer.valueOf(txtIdMod.getText()));
			estagio.setModalidade_estagio(Integer.valueOf(txtModalidade.getText()));
			estagio.setData_inicio(txtDataInicio.getText());
			estagio.setData_fim(txtDataFim.getText());
			estagio.setData_previsao_entrega(Integer.valueOf(txtDtPreEnt.getText()));
			estagio.setData_cadastro(txtDataCad.getText());		
							
			boolean resultado = cieeController.excluir(estagio);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(286, 377, 117, 29);
		contentPane.add(btnExcluir);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(16, 356, 530, 12);
		contentPane.add(horizontalStrut);
	}
}