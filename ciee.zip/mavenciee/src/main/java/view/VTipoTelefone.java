package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.TipoTelefoneController;
import model.TipoTelefone;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class VTipoTelefone extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtTipo;
	private JTable tbTipoTelefone;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VTipoTelefone frame = new VTipoTelefone();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VTipoTelefone() {
		setTitle("Cadastro Telefone");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 307);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TipoTelefone tipotelefone = new TipoTelefone();
				TipoTelefoneController cieeController = new TipoTelefoneController();
										
				tipotelefone.setId(Integer.valueOf(txtId.getText()));
				tipotelefone.setTipo(txtTipo.getText());
				
				
				boolean resultado = cieeController.salvar(tipotelefone);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(46, 206, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(379, 206, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 551, 189);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(22, 21, 12, 16);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtId = new JTextField();
		txtId.setBounds(21, 43, 95, 26);
		txtId.setColumns(10);
		
		JLabel lblTipoTelefone = new JLabel("Tipo de telefone");
		lblTipoTelefone.setBounds(144, 21, 105, 16);
		lblTipoTelefone.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtTipo = new JTextField();
		txtTipo.setBounds(144, 44, 145, 26);
		txtTipo.setColumns(10);
		panel.setLayout(null);
		panel.add(txtId);
		panel.add(lblId);
		panel.add(lblTipoTelefone);
		panel.add(txtTipo);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 115, 530, 12);
		panel.add(horizontalStrut);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from tipotelefone";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbTipoTelefone.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("tipo")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 113);
		panel_1.add(scrollPane);
		
		tbTipoTelefone = new JTable();
		tbTipoTelefone.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbTipoTelefone.getSelectedRow();
				
						
				
				txtId.setText(tbTipoTelefone.getValueAt(linha, 0).toString());
				txtTipo.setText(tbTipoTelefone.getValueAt(linha, 1).toString());
				
					
			}
		});
		tbTipoTelefone.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbTipoTelefone.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
			},
			new String[] {
				"ID", "TIPO DE TELEFONE"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbTipoTelefone.getColumnModel().getColumn(0).setPreferredWidth(155);
		tbTipoTelefone.getColumnModel().getColumn(1).setPreferredWidth(135);
		scrollPane.setViewportView(tbTipoTelefone);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				TipoTelefone tipotelefone = new TipoTelefone();
				TipoTelefoneController cieeController = new TipoTelefoneController();
				
							
				tipotelefone.setId(Integer.valueOf(txtId.getText()));
				tipotelefone.setTipo(txtTipo.getText());
								
								
				boolean resultado = cieeController.alterar(tipotelefone);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(159, 206, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			TipoTelefone tipotelefone = new TipoTelefone();
			TipoTelefoneController cieeController = new TipoTelefoneController();

			tipotelefone.setId(Integer.valueOf(txtId.getText()));
			tipotelefone.setTipo(txtTipo.getText());
							
			boolean resultado = cieeController.excluir(tipotelefone);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(269, 206, 117, 29);
		contentPane.add(btnExcluir);
	}
}