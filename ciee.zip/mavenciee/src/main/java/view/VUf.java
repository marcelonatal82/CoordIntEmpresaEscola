package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.UfController;
import model.Cidade;
import model.UF;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class VUf extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdUF;
	private JTextField txtUF;
	private JTable tbUF;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VUf frame = new VUf();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VUf() {
		setTitle("CADASTRO DE CIDADE");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 483, 287);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(16, 191, 117, 29);
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UF uf = new UF();
				UfController cieeController = new UfController();
				
					
				uf.setId(Integer.valueOf(txtIdUF.getText()));
				uf.setUf(txtUF.getText());
											
				
				
				boolean resultado = cieeController.salvar(uf);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.setBounds(349, 191, 117, 29);
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 356, 174);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblIdUF = new JLabel("Id");
		lblIdUF.setBounds(22, 21, 12, 16);
		lblIdUF.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtIdUF = new JTextField();
		txtIdUF.setBounds(21, 43, 64, 26);
		txtIdUF.setColumns(10);
		panel.setLayout(null);
		panel.add(txtIdUF);
		panel.add(lblIdUF);
		
		JLabel lblNomeCidade = new JLabel("Unidade da Federação (UF)");
		lblNomeCidade.setBounds(22, 78, 205, 16);
		lblNomeCidade.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblNomeCidade);
		
		txtUF = new JTextField();
		txtUF.setBounds(21, 94, 73, 20);
		panel.add(txtUF);
		txtUF.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from uf";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbUF.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("uf")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 320, 98);
		panel_1.add(scrollPane);
		
		tbUF = new JTable();
		tbUF.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbUF.getSelectedRow();
								
			
				txtIdUF.setText(tbUF.getValueAt(linha, 0).toString());
				txtUF.setText(tbUF.getValueAt(linha, 1).toString());
				
					
			}
		});
		tbUF.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbUF.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
			},
			new String[] {
				"ID", "UF"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbUF.getColumnModel().getColumn(0).setPreferredWidth(155);
		tbUF.getColumnModel().getColumn(1).setPreferredWidth(128);
		
		scrollPane.setViewportView(tbUF);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(129, 191, 117, 29);
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				UF uf = new UF();
				UfController cidadeController = new UfController();
				
				uf.setId(Integer.valueOf(txtIdUF.getText()));
				uf.setUf(txtUF.getText());
										
									
												
								
				boolean resultado = cidadeController.alterar(uf);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(239, 191, 117, 29);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			UF uf = new UF();
			UfController cidadeController = new UfController();
			

			
			uf.setId(Integer.valueOf(txtIdUF.getText()));
			uf.setUf(txtUF.getText());
										
							
			boolean resultado = cidadeController.excluir(uf);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		contentPane.add(btnExcluir);
	}
}