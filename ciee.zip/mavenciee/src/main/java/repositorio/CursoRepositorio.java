package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.Curso;

public class CursoRepositorio implements Serializable{

	Logger logger = Logger.getLogger(CursoRepositorio.class);
	
	public boolean salvar(Curso modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO curso (id, nome_curso, carga_horaria_estagio, data_cadastro) values (?, ?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setString(2, modelo.getNome_curso());
			preparedStatement1.setInt(3, modelo.getCarga_horaria_estagio());				
			preparedStatement1.setDate(4, java.sql.Date.valueOf(modelo.getData_cadastro()));
			
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de aluno: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de aluno: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(Curso modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update aluno set nome_curso = ?, carga_horaria_estagio = ?, data_cadastro = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setString(2, modelo.getNome_curso());
			preparedStatement1.setInt(3, modelo.getCarga_horaria_estagio());				
			preparedStatement1.setDate(4, java.sql.Date.valueOf(modelo.getData_cadastro()));
						
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de aluno: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de aluno: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(Curso modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from curso where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do Curso preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de Curso: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de Curso: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}

	public boolean buscar(Curso modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Curso buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from curso "
							+ "where id = ?";
			Curso curso = new Curso();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				curso.setId(resultSet.getInt("id"));
				curso.setNome_curso(resultSet.getString("nome curso"));
				curso.setCarga_horaria_estagio(resultSet.getInt("Carga Horaria"));
				curso.setData_cadastro(resultSet.getDate("data_cadastro").toLocalDate());
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return curso;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um Curso: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<Curso> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from curso";
			List<Curso> lista = new ArrayList<Curso>();
			Curso curso;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				curso = new Curso();
				curso.setId(resultSet.getInt("id"));
				curso.setNome_curso(resultSet.getString("nome curso"));
				curso.setCarga_horaria_estagio(resultSet.getInt("Carga Horaria"));
				curso.setData_cadastro(resultSet.getDate("data_cadastro").toLocalDate());
				lista.add(curso);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do Curso: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
