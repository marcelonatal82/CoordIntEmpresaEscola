package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.AlunoTelefone;

public class AlunoTelefoneRepositorio implements Serializable{

	Logger logger = Logger.getLogger(AlunoTelefoneRepositorio.class);
	
	public boolean salvar(AlunoTelefone modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO alunotelefone (id, telefone, tipotelefone) values (?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setString(2, modelo.getTelefone());
			//preparedStatement1.setString(3, modelo.getSelectedItem().toString());
			
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(AlunoTelefone modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update alunotelefone set telefone = ?, tipotelefone = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setString(2, modelo.getTelefone());
			preparedStatement1.setString(3, modelo.getTipoTelefone());
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(AlunoTelefone modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from alunotelefone where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do aluno preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de alunotelefone: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}


	public AlunoTelefone buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from alunotelefone "
							+ "where id = ?";
			AlunoTelefone alunotelefone = new AlunoTelefone();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				alunotelefone.setId(resultSet.getInt("id"));
				alunotelefone.setTelefone(resultSet.getString("Telefone"));
				
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return alunotelefone;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um alunotelefone: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<AlunoTelefone> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from alunotelefone";
			List<AlunoTelefone> lista = new ArrayList<AlunoTelefone>();
			AlunoTelefone alunotelefone;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				alunotelefone = new AlunoTelefone();
				alunotelefone.setId(resultSet.getInt("id"));
				alunotelefone.setTelefone(resultSet.getString("Telefone"));
				alunotelefone.setTipoTelefone(resultSet.getString("Tipo Telefone"));
				
				lista.add(alunotelefone);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do alunotelefone: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
