package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.Servidor;

public class ServidorRepositorio implements Serializable{

	Logger logger = Logger.getLogger(ServidorRepositorio.class);
	
	public boolean salvar(Servidor modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO servidor (id, nome, matricula, email, data_cadastro) values (?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setString(2, modelo.getNome());
			preparedStatement1.setString(3, modelo.getMatricula());	
			preparedStatement1.setString(4, modelo.getEmail());
			preparedStatement1.setDate(5, java.sql.Date.valueOf(modelo.getData_cadastro()));
			
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de Servidor: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de Servidor: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(Servidor modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update servidor set nome = ?, matricula = ?, email = ?, data_cadastro = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			
			preparedStatement1.setString(1, modelo.getNome());
			preparedStatement1.setString(2, modelo.getMatricula());	
			preparedStatement1.setString(3, modelo.getEmail());
			preparedStatement1.setDate(4, java.sql.Date.valueOf(modelo.getData_cadastro()));
			preparedStatement1.setInt(5, modelo.getId());
			//logger.info("String update do Servidor preparada: " + preparedStatement1);
						
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de servidor: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de servidor: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(Servidor modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from servidor where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do Curso preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de Servidor: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de Servidor: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}

	public boolean buscar(Servidor modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Servidor buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from servidor "
							+ "where id = ?";
			Servidor servidor = new Servidor();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				servidor.setId(resultSet.getInt("id"));
				servidor.setNome(resultSet.getString("nome Servidor"));
				servidor.setMatricula(resultSet.getString("Matricula"));
				servidor.setEmail(resultSet.getString("Email"));
				servidor.setData_cadastro(resultSet.getDate("data_cadastro").toLocalDate());
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return servidor;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um Servidor: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<Servidor> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from curso";
			List<Servidor> lista = new ArrayList<Servidor>();
			Servidor servidor;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				servidor = new Servidor();
				servidor.setId(resultSet.getInt("id"));
				servidor.setNome(resultSet.getString("nome Servidor"));
				servidor.setMatricula(resultSet.getString("Matricula"));
				servidor.setEmail(resultSet.getString("Email"));
				servidor.setData_cadastro(resultSet.getDate("data_cadastro").toLocalDate());
				lista.add(servidor);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do Servidor: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
