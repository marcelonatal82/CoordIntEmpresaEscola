package model;

public class ConcedenteTelefone {

    private int id;

    private String telefone;

    private Concedente concedente;

}
