package model;

import java.util.Collection;
import java.util.List;

import controller.TipoTelefoneController;

public class TipoTelefone {

    private int id;
    private String tipo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


	public void removeAll() {
		// TODO Auto-generated method stub
		
	}

	public void addItem(TipoTelefone f) {
		// TODO Auto-generated method stub
		
	}

	public TipoTelefoneController TipoTelefoneController() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<TipoTelefone> listartipoTelefone() {
		// TODO Auto-generated method stub
		return null;
	}
		@Override
		public String toString() {
		return this.getTipo();
	}

}
