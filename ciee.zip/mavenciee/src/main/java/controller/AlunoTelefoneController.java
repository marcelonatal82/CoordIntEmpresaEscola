package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.AlunoTelefone;
import repositorio.AlunoTelefoneRepositorio;

public class AlunoTelefoneController implements Serializable{

	AlunoTelefoneRepositorio repositorio = new AlunoTelefoneRepositorio();
	
	public boolean salvar(AlunoTelefone modelo) {
		if (modelo.getTelefone().isEmpty()==false) {
			System.out.println(modelo.getTelefone());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(AlunoTelefone modelo) {
					
		if (modelo.getTelefone().isEmpty()==false) {
				System.out.println(modelo.getTelefone());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(AlunoTelefone modelo){
		if (modelo.getTelefone().isEmpty() == false) {
			System.out.println(modelo.getTelefone());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(AlunoTelefone modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public AlunoTelefone buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<AlunoTelefone> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
