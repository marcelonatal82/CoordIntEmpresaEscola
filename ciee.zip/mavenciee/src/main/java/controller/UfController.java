package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;


import model.UF;
import repositorio.UfRepositorio;
import controller.IController;

public class UfController implements Serializable{

	UfRepositorio repositorio = new UfRepositorio();
	
	public boolean salvar(UF modelo) {
		if (modelo.getUf().isEmpty()==false) {
			System.out.println(modelo.getUf());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(UF modelo) {
					
		if (modelo.getUf().isEmpty()==false) {
				System.out.println(modelo.getUf());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(UF modelo){
		if (modelo.getUf().isEmpty() == false) {
			System.out.println(modelo.getUf());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(UF modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public UF buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UF> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
