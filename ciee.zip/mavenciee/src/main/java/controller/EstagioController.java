package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.Estagio;
import repositorio.EstagioRepositorio;

public class EstagioController implements Serializable{

	EstagioRepositorio repositorio = new EstagioRepositorio();
	
	public boolean salvar(Estagio modelo) {
		if (modelo.getData_cadastro().isEmpty()==false) {
			System.out.println(modelo.getData_cadastro());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(Estagio modelo) {
					
		if (modelo.getData_cadastro().isEmpty()==false) {
				System.out.println(modelo.getData_cadastro());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(Estagio modelo){
		if (modelo.getData_cadastro().isEmpty() == false) {
			System.out.println(modelo.getData_cadastro());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(Estagio modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Estagio buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Estagio> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
